export type Member = {
  id: string;
  fullName: string;     // ✅ Họ tên
  role: string;         // ✅ Vai trò trong nhóm
  shortBio: string;     // ✅ Mô tả ngắn
  imageSrc: string;     // ✅ Ảnh (đường dẫn trong /public)
};

export type Game = {
  id: string;
  name: string;         // ✅ Tên game
  imageSrc: string;     // ✅ Hình (đường dẫn trong /public)
  description: string;  // ✅ Mô tả
  story: string;        // ✅ Cốt truyện
  downloadUrl: string;  // ✅ Link tải
  demoVideoUrl: string; // ✅ Video demo (YouTube link hoặc link embed)
};

export const groupInfo = {
  // ⚠️ Tên nhóm theo yêu cầu đề bài (không đổi)
  name: "(Trễ Deadline)^-1",

  // ✅ Label — bạn chỉ cần điền
  foundingYear: "20XX",              // VD: "2024"
  logoSrc: "/logo-placeholder.svg",  // Thay bằng logo của nhóm trong /public
  slogan: "Điền slogan / mô tả ngắn của nhóm tại đây."
};

export const members: Member[] = [
  {
    id: "m1",
    fullName: "Họ tên thành viên 1",
    role: "Vai trò (VD: Leader / Dev / Artist / Tester...)",
    shortBio: "Mô tả ngắn (1–2 câu) về thành viên 1.",
    imageSrc: "/member-placeholder.svg"
  },
  {
    id: "m2",
    fullName: "Họ tên thành viên 2",
    role: "Vai trò (VD: Dev / Designer...)",
    shortBio: "Mô tả ngắn (1–2 câu) về thành viên 2.",
    imageSrc: "/member-placeholder.svg"
  },
  {
    id: "m3",
    fullName: "Họ tên thành viên 3",
    role: "Vai trò (VD: Artist / Writer...)",
    shortBio: "Mô tả ngắn (1–2 câu) về thành viên 3.",
    imageSrc: "/member-placeholder.svg"
  },
  {
    id: "m4",
    fullName: "Họ tên thành viên 4",
    role: "Vai trò (VD: QA / PM...)",
    shortBio: "Mô tả ngắn (1–2 câu) về thành viên 4.",
    imageSrc: "/member-placeholder.svg"
  }
];

export const games: Game[] = [
  {
    id: "g1",
    name: "Tên game 1",
    imageSrc: "/game-placeholder.svg",
    description: "Mô tả game 1 (thể loại, gameplay chính, điểm nổi bật...).",
    story: "Cốt truyện game 1 (tóm tắt bối cảnh, mục tiêu, nhân vật...).",
    downloadUrl: "https://example.com/download/game-1",
    demoVideoUrl: "https://www.youtube.com/watch?v=dQw4w9WgXcQ"
  },
  {
    id: "g2",
    name: "Tên game 2",
    imageSrc: "/game-placeholder.svg",
    description: "Mô tả game 2 ...",
    story: "Cốt truyện game 2 ...",
    downloadUrl: "https://example.com/download/game-2",
    demoVideoUrl: "https://www.youtube.com/watch?v=dQw4w9WgXcQ"
  },
  {
    id: "g3",
    name: "Tên game 3",
    imageSrc: "/game-placeholder.svg",
    description: "Mô tả game 3 ...",
    story: "Cốt truyện game 3 ...",
    downloadUrl: "https://example.com/download/game-3",
    demoVideoUrl: "https://www.youtube.com/watch?v=dQw4w9WgXcQ"
  },
  {
    id: "g4",
    name: "Tên game 4",
    imageSrc: "/game-placeholder.svg",
    description: "Mô tả game 4 ...",
    story: "Cốt truyện game 4 ...",
    downloadUrl: "https://example.com/download/game-4",
    demoVideoUrl: "https://www.youtube.com/watch?v=dQw4w9WgXcQ"
  },
  {
    id: "g5",
    name: "Tên game 5",
    imageSrc: "/game-placeholder.svg",
    description: "Mô tả game 5 ...",
    story: "Cốt truyện game 5 ...",
    downloadUrl: "https://example.com/download/game-5",
    demoVideoUrl: "https://www.youtube.com/watch?v=dQw4w9WgXcQ"
  }
];
